import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class Registrarse {
    private JPanel PanelEj_2;

    public Registrarse() {
        // Panel principal con imagen de fondo
        PanelEj_2 = new JPanel() {
            private Image fondo = new ImageIcon(getClass().getResource(
                    "/fondo rosa.jpg")).getImage(); // Cambia la ruta a tu imagen de fondo

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
            }
        };
        PanelEj_2.setLayout(new BorderLayout());

        // Logo grande centrado
        ImageIcon originalIcon = new ImageIcon(getClass().getResource(
                "/Black_and_White_Retro_Y2K_Streetwear_Clothing_Logo_INICIO_SESION (1).png"));

        int maxWidth = 280;
        int maxHeight = 280;
        int imgWidth = originalIcon.getIconWidth();
        int imgHeight = originalIcon.getIconHeight();
        double ratio = Math.min((double) maxWidth / imgWidth, (double) maxHeight / imgHeight);
        int newWidth = (int) (imgWidth * ratio);
        int newHeight = (int) (imgHeight * ratio);

        Image scaledImage = originalIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        JLabel label = new JLabel(new ImageIcon(scaledImage));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        PanelEj_2.add(label, BorderLayout.NORTH);

        // Panel central (formulario)
        JPanel registroPanel = new JPanel();
        registroPanel.setLayout(new BoxLayout(registroPanel, BoxLayout.Y_AXIS));
        registroPanel.setBorder(BorderFactory.createEmptyBorder(20, 100, 20, 100));
        registroPanel.setOpaque(false); // Para que se vea la imagen de fondo

        Font fuenteTitulo = new Font("SansSerif", Font.BOLD, 14);
        Font fuenteCampos = new Font("SansSerif", Font.PLAIN, 14);

        // --- Correo ---
        JPanel emailPanel = new JPanel(new BorderLayout());
        emailPanel.setOpaque(false);
        JLabel emailLabel = new JLabel("Correo:");
        emailLabel.setFont(fuenteTitulo);
        emailLabel.setForeground(Color.BLACK);
        JTextField emailField = new JTextField(15);
        emailField.setFont(fuenteCampos);
        emailField.setBackground(new Color(255, 255, 255, 180));
        emailField.setBorder(new LineBorder(new Color(150, 150, 150), 1, true));
        emailPanel.add(emailLabel, BorderLayout.NORTH);
        emailPanel.add(emailField, BorderLayout.CENTER);

        // --- Usuario ---
        JPanel userPanel = new JPanel(new BorderLayout());
        userPanel.setOpaque(false);
        JLabel userLabel = new JLabel("Usuario:");
        userLabel.setFont(fuenteTitulo);
        userLabel.setForeground(Color.BLACK);
        JTextField userField = new JTextField(15);
        userField.setFont(fuenteCampos);
        userField.setBackground(new Color(255, 255, 255, 180));
        userField.setBorder(new LineBorder(new Color(150, 150, 150), 1, true));
        userPanel.add(userLabel, BorderLayout.NORTH);
        userPanel.add(userField, BorderLayout.CENTER);

        // --- Contraseña ---
        JPanel passPanel = new JPanel(new BorderLayout());
        passPanel.setOpaque(false);
        JLabel passLabel = new JLabel("Contraseña:");
        passLabel.setFont(fuenteTitulo);
        passLabel.setForeground(Color.BLACK);
        JPasswordField passField = new JPasswordField(15);
        passField.setFont(fuenteCampos);
        passField.setBackground(new Color(255, 255, 255, 180));
        passField.setBorder(new LineBorder(new Color(150, 150, 150), 1, true));
        passPanel.add(passLabel, BorderLayout.NORTH);
        passPanel.add(passField, BorderLayout.CENTER);

        // Checkbox
        JCheckBox termsCheck = new JCheckBox("Aceptar términos y condiciones");
        termsCheck.setOpaque(false);
        termsCheck.setForeground(Color.BLACK);
        termsCheck.setFont(fuenteCampos);

        // Botón registrarse
        JButton registrarseButton = new JButton("Registrarse");
        registrarseButton.setBackground(Color.BLACK);
        registrarseButton.setForeground(Color.WHITE);
        registrarseButton.setFocusPainted(false);
        registrarseButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        registrarseButton.setBorder(new RoundedBorder(10));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        buttonPanel.add(registrarseButton);

        // Agregar todo al panel principal
        registroPanel.add(emailPanel);
        registroPanel.add(Box.createVerticalStrut(10));
        registroPanel.add(userPanel);
        registroPanel.add(Box.createVerticalStrut(10));
        registroPanel.add(passPanel);
        registroPanel.add(Box.createVerticalStrut(10));
        registroPanel.add(termsCheck);
        registroPanel.add(Box.createVerticalStrut(15));
        registroPanel.add(buttonPanel);

        PanelEj_2.add(registroPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Registrarse");

        Image icon = new ImageIcon(Registrarse.class.getResource(
                "/icono.png")).getImage();
        frame.setIconImage(icon);

        frame.setContentPane(new Registrarse().PanelEj_2);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.pack();
        frame.setMinimumSize(new Dimension(500, 600));
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    static class RoundedBorder implements javax.swing.border.Border {
        private int radius;
        RoundedBorder(int radius) { this.radius = radius; }
        public Insets getBorderInsets(Component c) { return new Insets(radius + 1, radius + 1, radius + 2, radius); }
        public boolean isBorderOpaque() { return true; }
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
        }
    }
}
