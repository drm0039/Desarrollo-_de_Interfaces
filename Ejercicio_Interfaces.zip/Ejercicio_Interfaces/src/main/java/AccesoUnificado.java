import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;

public class AccesoUnificado {

    private JProgressBar progressBar;

    public AccesoUnificado() {
        // --- CONFIGURACIÓN GENERAL DE LA VENTANA ---
        JFrame frame = new JFrame("Acceso de Usuario");
        Image icon = new ImageIcon(AccesoUnificado.class.getResource("/icono.png")).getImage();
        frame.setIconImage(icon);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(500, 700));
        frame.setLocationRelativeTo(null);

        // --- PANEL PRINCIPAL CON BORDERLAYOUT ---
        JPanel mainPanel = new JPanel(new BorderLayout());

        // --- BARRA DE PROGRESO ---
        progressBar = new JProgressBar();
        progressBar.setIndeterminate(true);
        progressBar.setVisible(false);
        JPanel progressPanel = new JPanel(new BorderLayout());
        progressPanel.add(progressBar, BorderLayout.CENTER);
        mainPanel.add(progressPanel, BorderLayout.SOUTH);

        // --- PANEL CON PESTAÑAS ---
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("SansSerif", Font.BOLD, 14));

        // --- PESTAÑA 1: INICIAR SESIÓN ---
        JPanel loginPanel = createLoginPanel();
        tabbedPane.addTab("Iniciar Sesión", loginPanel);

        // --- PESTAÑA 2: REGISTRARSE ---
        JPanel registerPanel = createRegisterPanel();
        tabbedPane.addTab("Registrarse", registerPanel);

        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        frame.setContentPane(mainPanel);
        frame.setVisible(true);
    }

    private JPanel createLoginPanel() {
        JPanel panel = createBackgroundPanel("/fondo rayo.png");

        // Panel para el formulario
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 100, 20, 100));
        formPanel.setOpaque(false);

        Font fuenteTitulo = new Font("SansSerif", Font.BOLD, 14);
        Font fuenteCampos = new Font("SansSerif", Font.PLAIN, 14);

        // Campos del formulario
        formPanel.add(createFieldPanel("Correo:", new JTextField(15), fuenteTitulo, Color.WHITE));
        formPanel.add(Box.createVerticalStrut(10));
        formPanel.add(createFieldPanel("Contraseña:", new JPasswordField(15), fuenteTitulo, Color.WHITE));
        formPanel.add(Box.createVerticalStrut(10));

        // --- ComboBox Idiomas ---
        JPanel idiomaPanel = new JPanel(new BorderLayout());
        idiomaPanel.setOpaque(false);
        JLabel idiomaLabel = new JLabel("Escoger idioma:");
        idiomaLabel.setFont(fuenteTitulo);
        idiomaLabel.setForeground(Color.WHITE);
        String[] idiomas = {"Español", "Inglés", "Italiano", "Portugués", "Chino"};
        JComboBox<String> idiomaCombo = new JComboBox<>(idiomas);
        idiomaCombo.setFont(fuenteCampos);
        idiomaCombo.setBackground(new Color(255, 255, 255, 180));
        idiomaCombo.setBorder(new LineBorder(new Color(150, 150, 150), 1, true));
        idiomaPanel.add(idiomaLabel, BorderLayout.NORTH);
        idiomaPanel.add(idiomaCombo, BorderLayout.CENTER);
        formPanel.add(idiomaPanel);
        formPanel.add(Box.createVerticalStrut(10));

        // Checkbox de términos
        JCheckBox termsCheck = new JCheckBox("Acepto los términos y condiciones");
        styleCheckBox(termsCheck, Color.WHITE);
        formPanel.add(termsCheck);
        formPanel.add(Box.createVerticalStrut(15));

        // Botón
        JButton loginButton = new JButton("Iniciar Sesión");
        styleButton(loginButton);
        loginButton.addActionListener(e -> startLoadingProcess(termsCheck, "¡Inicio de sesión exitoso!"));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        buttonPanel.add(loginButton);
        formPanel.add(buttonPanel);

        panel.add(formPanel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createRegisterPanel() {
        JPanel panel = createBackgroundPanel("/fondo vegetacion.png");

        // Panel para el formulario
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 100, 20, 100));
        formPanel.setOpaque(false);

        Font fuenteTitulo = new Font("SansSerif", Font.BOLD, 14);

        // Campos del formulario
        formPanel.add(createFieldPanel("Correo:", new JTextField(15), fuenteTitulo, Color.WHITE));
        formPanel.add(Box.createVerticalStrut(10));

        // --- Spinner Edad ---
        JPanel edadPanel = new JPanel(new BorderLayout());
        edadPanel.setOpaque(false);
        JLabel edadLabel = new JLabel("Edad:");
        edadLabel.setFont(fuenteTitulo);
        edadLabel.setForeground(Color.WHITE);

        SpinnerModel edadModel = new SpinnerNumberModel(18, 18, 99, 1); // (valor inicial, mínimo, máximo, paso)
        JSpinner edadSpinner = new JSpinner(edadModel);
        edadSpinner.setFont(new Font("SansSerif", Font.PLAIN, 14));
        JComponent editor = edadSpinner.getEditor();
        if (editor instanceof JSpinner.DefaultEditor) {
            ((JSpinner.DefaultEditor) editor).getTextField().setBackground(new Color(255, 255, 255, 180));
        }

        edadPanel.add(edadLabel, BorderLayout.NORTH);
        edadPanel.add(edadSpinner, BorderLayout.CENTER);
        formPanel.add(edadPanel);
        formPanel.add(Box.createVerticalStrut(10));

        formPanel.add(createFieldPanel("Contraseña:", new JPasswordField(15), fuenteTitulo, Color.WHITE));
        formPanel.add(Box.createVerticalStrut(10));

        // Checkbox de términos
        JCheckBox termsCheck = new JCheckBox("Acepto los términos y condiciones");
        styleCheckBox(termsCheck, Color.WHITE);
        formPanel.add(termsCheck);
        formPanel.add(Box.createVerticalStrut(15));

        // Botón
        JButton registerButton = new JButton("Registrarse");
        styleButton(registerButton);
        registerButton.addActionListener(e -> startLoadingProcess(termsCheck, "¡Registro completado!"));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        buttonPanel.add(registerButton);
        formPanel.add(buttonPanel);

        panel.add(formPanel, BorderLayout.CENTER);
        return panel;
    }

    // --- MÉTODOS DE AYUDA Y LÓGICA ---

    private void startLoadingProcess(JCheckBox termsCheck, String successMessage) {
        if (!termsCheck.isSelected()) {
            JOptionPane.showMessageDialog(null, "Debes aceptar los términos y condiciones.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        progressBar.setVisible(true);

        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                Thread.sleep(2000); // Simula una tarea de 2 segundos
                return null;
            }

            @Override
            protected void done() {
                progressBar.setVisible(false);
                JOptionPane.showMessageDialog(null, successMessage, "Proceso Completado", JOptionPane.INFORMATION_MESSAGE);
            }
        };

        worker.execute();
    }

    private JPanel createBackgroundPanel(String imagePath) {
        JPanel panel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image fondo = new ImageIcon(AccesoUnificado.class.getResource(imagePath)).getImage();
                g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
            }
        };

        // Logo (con escalado original)
        ImageIcon originalIcon = new ImageIcon(AccesoUnificado.class.getResource("/Black_and_White_Retro_Y2K_Streetwear_Clothing_Logo_INICIO_SESION (1).png"));
        int maxWidth = 280;
        int maxHeight = 280;
        int imgWidth = originalIcon.getIconWidth();
        int imgHeight = originalIcon.getIconHeight();
        double ratio = Math.min((double) maxWidth / imgWidth, (double) maxHeight / imgHeight);
        int newWidth = (int) (imgWidth * ratio);
        int newHeight = (int) (imgHeight * ratio);

        Image scaledImage = originalIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        JLabel label = new JLabel(new ImageIcon(scaledImage));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(label, BorderLayout.NORTH);

        return panel;
    }

    private JPanel createFieldPanel(String labelText, JComponent field, Font labelFont, Color labelColor) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        JLabel label = new JLabel(labelText);
        label.setFont(labelFont);
        label.setForeground(labelColor);
        field.setFont(new Font("SansSerif", Font.PLAIN, 14));
        field.setBackground(new Color(255, 255, 255, 180));
        field.setBorder(new LineBorder(new Color(150, 150, 150), 1, true));

        panel.add(label, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    private void styleButton(JButton button) {
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBorder(new RoundedBorder(10));
    }

    private void styleCheckBox(JCheckBox checkBox, Color color) {
        checkBox.setOpaque(false);
        checkBox.setForeground(color);
        checkBox.setFont(new Font("SansSerif", Font.PLAIN, 14));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AccesoUnificado::new);
    }

    static class RoundedBorder implements Border {
        private final int radius;
        RoundedBorder(int radius) { this.radius = radius; }
        public Insets getBorderInsets(Component c) { return new Insets(radius + 1, radius + 1, radius + 2, radius); }
        public boolean isBorderOpaque() { return true; }
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
        }
    }
}
